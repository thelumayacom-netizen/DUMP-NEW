import HeroSection from "@/components/HeroSection";

const Index = () => {
  return (
    <main>
      <HeroSection />
    </main>
  );
};

export default Index;
